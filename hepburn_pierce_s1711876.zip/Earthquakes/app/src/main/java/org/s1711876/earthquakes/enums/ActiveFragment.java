// Name                 Pierce hepburn
// Student ID           S1711876
// Programme of Study   Computing

package org.s1711876.earthquakes.enums;

// enum used when getting the active fragment
public enum ActiveFragment {
    REGISTER,
    MAP,
    GRAPH
}
